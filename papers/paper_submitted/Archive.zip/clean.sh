rm ms.synctex.gz ms.log ms.out ms.aux ms.blg ms.bbl
